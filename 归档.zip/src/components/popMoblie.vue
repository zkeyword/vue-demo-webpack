<style lang="less">
@import '../less/lib/mixins.less';
.actions-modal.actions-top{
	z-index:11000;
	background:#fff;
	top:2.2rem;
	.rem(height, 200);
}
</style>

<template>
	dfg
</template>

<script>
    export default {
        replace:true,
        props: ['isShow'],
        ready: function () {
			
        }
    }
</script>