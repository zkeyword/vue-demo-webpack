<template>
  <div class="item"><slot></slot></div>
</template>
