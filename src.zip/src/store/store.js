import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
	state: {
		namexx: 'xxxxxxxxxxxxxx'
	},
	actions: {
		namexx2(){
			return 111
		}
	}
});
